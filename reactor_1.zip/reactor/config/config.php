<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$siteurl = 'http://mmttechmaaxxpos.com/';
$url_suffix = '';
$encryption_key = 'EkPA4ftFCFovAfBBJHFbIVTlqcrlo6F2';
$defaultmodule = 'dashboard';
$enabledatabase=TRUE;