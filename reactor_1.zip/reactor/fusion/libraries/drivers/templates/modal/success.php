<?php

/* 
 * Copyright 2017 Increatech Business Solution Pvt Ltd, India.
 * All Rights Reserved
 * www.increatech.com
 */
?>

<div id="modalSuccess" class="modal-block modal-block-success modal-header-color ">
        <div class="panel panel-color panel-success">

                <div class="panel-heading">

                        <h2 class="panel-title">Success!</h2>
                </div>
                <div class="panel-body">
                    <div class="alert alert-icon alert-success fade in" role="alert">
                        <i class="mdi mdi-check-all"></i>
                        <?=$msg;?>
                    </div>
                </div>
                <div class="panel-footer">

                        <div class="row">
                                <div class="col-md-12 text-right">
                                        <button class="btn btn-success modal-dismiss">OK</button>
                                </div>
                        </div>
                </div>

        </div>

</div>


