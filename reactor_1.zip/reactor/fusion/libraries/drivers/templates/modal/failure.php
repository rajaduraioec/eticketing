<?php

/* 
 * Copyright 2017 Increatech Business Solution Pvt Ltd, India.
 * All Rights Reserved
 * www.increatech.com
 */

?>
<div id="modalWarning" class="modal-block modal-block-warning modal-header-color ">
    <div class="panel panel-color panel-warning">

        <div class="panel-heading">

                <h2 class="panel-title">Oops!</h2>
        </div>
        <div class="panel-body">
                <div class="modal-wrapper">
                    <div class="alert alert-icon alert-warning fade in" role="alert">
                        <i class="mdi mdi-close-octagon-outline"></i>
                        <?=$msg;?>
                    </div>
                </div>
        </div>
        <div class="panel-footer">

                <div class="row">
                        <div class="col-md-12 text-right">
                                <button class="btn btn-warning modal-dismiss">OK</button>
                        </div>
                </div>
        </div>

    </div>

</div>
