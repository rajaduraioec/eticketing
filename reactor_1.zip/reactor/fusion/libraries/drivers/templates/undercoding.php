<?php

if (!defined('RAPPVERSION'))
    exit('No direct script access allowed');
/* 
 * 
 * @package	MMT Transport E-Ticketing
 * @Framework	Reactor Framework
 * @author         Increatech Dev Team
 * @copyright	Copyright (c) Since 2017, Increatech Business Solution Pvt Ltd, India (http://increatech.com/)
 * @link           https://increatech.com
 * @since          Version 1.0.0
 * @module      Buses
 * @filesource  Buses.views.view
 */
 
 ?>
<div class="row">
    <div class="col-sm-12" align="center">
        <div class="card-box">
            <h2>UNDER DEVELOPMENT</h2>
            <img src="<?=$this->rview->assets('coding.gif','images');?>" alt="">
        </div>
    </div>
</div>

