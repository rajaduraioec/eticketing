<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

/* load the MX_Router class */
require APPPATH."libraries/modular/Router.php";

class ICT_Router extends MX_Router {}