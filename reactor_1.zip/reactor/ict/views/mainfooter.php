<?=$footer;?>
            </div>
        </div>
        <script src="<?=$this->rview->assets('bootstrap.min.js','js');?>"></script>
        <script src="<?=$this->rview->assets('jquery.slimscroll.js','js');?>"></script>
        <script src="<?=$this->rview->assets('jquery.scrollTo.min.js','js');?>"></script>
        <script src="<?=$this->rview->plugin('jquery.dataTables.min.js','datatables');?>"></script>
        <script src="<?=$this->rview->plugin('dataTables.bootstrap.js','datatables');?>"></script>
        <script src="<?=$this->rview->plugin('dataTables.buttons.min.js','datatables');?>"></script>
        <script src="<?=$this->rview->plugin('buttons.bootstrap.min.js','datatables');?>"></script>
        <script src="<?=$this->rview->plugin('jszip.min.js','datatables');?>"></script>
        <script src="<?=$this->rview->plugin('pdfmake.min.js','datatables');?>"></script>
        <script src="<?=$this->rview->plugin('vfs_fonts.js','datatables');?>"></script>
        <script src="<?=$this->rview->plugin('buttons.html5.min.js','datatables');?>"></script>
        <script src="<?=$this->rview->plugin('buttons.print.min.js','datatables');?>"></script>
        <script src="<?=$this->rview->plugin('dataTables.responsive.min.js','datatables');?>"></script>
        <script src="<?=$this->rview->plugin('responsive.bootstrap.min.js','datatables');?>"></script>
        <script src="<?=$this->rview->plugin('jquery.validate.min.js','jquery-validation');?>"></script>
        <script src="<?=$this->rview->plugin('pattern.js','jquery-validation');?>"></script>
        <script src="<?=$this->rview->plugin('jquery.magnific-popup.min.js','magnific-popup');?>"></script>
        <script src="<?=$this->rview->plugin('select2.min.js','select2');?>"></script>
        <script src="<?=$this->rview->plugin('switchery.min.js','switchery');?>"></script>
        <script src="<?=$this->rview->plugin('jquery.toast.min.js','jquery-toastr');?>"></script>
        <script src="<?=$this->rview->plugin('pace.min.js','pace');?>"></script>
        <script src="<?=$this->rview->plugin('moment.js','moment');?>"></script>
        <script src="<?=$this->rview->plugin('daterangepicker.js','bootstrap-daterangepicker');?>"></script>
        <script src="<?=$this->rview->init('jquery.ict.ajax.init');?>"></script>
        <script src="<?=$this->rview->init('jquery.ict-modals.ajax.init');?>"></script>
        <script src="<?=$this->rview->init('jquery.select.init');?>"></script>
        <script src="<?=$this->rview->assets('jquery.core.js','js');?>"></script>
        <script src="<?=$this->rview->assets('jquery.app.js','js');?>"></script>
    </body>