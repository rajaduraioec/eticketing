<!DOCTYPE html>
<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        <title>MMT Transport</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta content="Application for MMT Transport developed by Increatech Business Solution Pvt Ltd" name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <link href="<?=$this->rview->assets('bootstrap.min.css','css');?>" rel="stylesheet" type="text/css" />
        <link href="<?=$this->rview->assets('core.css','css');?>" rel="stylesheet" type="text/css" />
        <link href="<?=$this->rview->assets('components.css','css');?>" rel="stylesheet" type="text/css" />
        <link href="<?=$this->rview->assets('icons.css','css');?>" rel="stylesheet" type="text/css" />
        <link href="<?=$this->rview->assets('pages.css','css');?>" rel="stylesheet" type="text/css" />
        <link href="<?=$this->rview->assets('menu.css','css');?>" rel="stylesheet" type="text/css" />
        <link href="<?=$this->rview->assets('responsive.css','css');?>" rel="stylesheet" type="text/css" />
        <script src="<?=$this->rview->assets('modernizr.min.js','js');?>"></script>
    </head>
    <body class="bg-accpunt-pages">
        <section>
                <?php print_r($subview); ?>
          </section>
        <script src="<?=$this->rview->assets('jquery.min.js','js');?>"></script>
        <script src="<?=$this->rview->assets('bootstrap.min.js','js');?>"></script>
        <script src="<?=$this->rview->assets('waves.js','js');?>"></script>
        <script src="<?=$this->rview->assets('jquery.slimscroll.js','js');?>"></script>
        <script src="<?=$this->rview->assets('jquery.scrollTo.min.js','js');?>"></script>
        <script src="<?=$this->rview->assets('jquery.core.js','js');?>"></script>
        <script src="<?=$this->rview->assets('jquery.app.js','js');?>"></script>
    </body>
</html>